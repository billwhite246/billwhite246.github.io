<?php

/**
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * @author Bill E-mail scompany@vip.qq.com
 * @date 2019年4月10日 20点39分
 * @version Beat1.0
 * 轻量级PHP持久层接口类
 * 仿Java - Hibernate 持久层使用方法
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 若以独立文件的形式获取到 该 Bean.class.php, 注意 __construct方法中的
 * DB_HOST, DB_USER, DB_PASSWD, DB_NAME
 * 需要定义全局变量 或者 替换成 自己引入的变量
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 接口列表
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
    save($table_name, $arr_save)
    table_name       |   pb_user
    arr_save         |   array('name=testname', 'phone=testphone', ...)
    return ————————————————————————————
    Array ( [status] => success [data] => )
    Array ( [status] => mysqli_error_message [data] => )
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    save($table_name, $arr_save, $arr_condition)
    table_name       |   pb_user
    arr_save         |   array('name=testname', 'phone=testphone', ...)
    arr_condition    |   array('id>13', 'age=18', 'score<>100', ...)
    return ————————————————————————————
    Array ( [status] => success [data] => )
    Array ( [status] => mysqli_error_message [data] => )
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    findByX($arr_findByWhat, $table_name, $arr_condition)
    arr_findByWhat   |   array('userid', 'phone', ...) 
    table_name       |   pb_user
    arr_condition    |   array('age=18', 'phone=15010988888', ...)
    return ————————————————————————————
    Array ( [status] => nodata [data] => Array ( ) )
    Array ( [status] => data [data] => Array ( [0] => Array ( [userid] => 1 [phone] => 15010988888 ) ) )
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    remove($table_name, $arr_condition)
    table_name       |   pb_user
    arr_condition    |   array('age=18', 'phone=15010988888', ...)
    return ————————————————————————————
    Array ( [status] => success [data] => )
    Array ( [status] => mysqli_error_message [data] => )
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 */

class Bean{

    public $_mysqli;

    function __construct(){
        // 连接数据库
        @$this->_mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWD, DB_NAME);
        // echo "DB_HOST=" . DB_HOST . '<br/>';
        // echo "DB_USER=" . DB_USER . '<br/>';
        // echo "DB_PASSWD=" . DB_PASSWD . '<br/>';
        // echo "DB_NAME=" . DB_NAME . '<br/>';
        // @$this->_mysqli = new mysqli("127.0.0.1", "ahutsrtp1", "ahutsrtp1", "ahutsrtp1");
        // $this->mysqli->set_charset("utf8");
    }

    /**
     * 自定义复杂mysql语句区域
     * 当上述四个基础函数不足以提供符合语句的要求时，可自己自定义语句进行操作
     * 注意符合 Array ( [status] =>  [data] =>  ) 返回规范
     * ==================================================================
     * ======================== 自定义语句区开始 ==========================
     * ==================================================================
     */



    /**
    * ==================================================================
    * ======================== 自定义语句区结束 ==========================
    * ==================================================================
    */

    /**
     * ================================================================== // ======================= //
     * ====================== 以下区域建议不要改动 ======================== // ======================= //
     * ================================================================== // ======================= //
     */

    
    /**
     * 防SQL注入
     * @param int/string p
     * @return int/string safe-paramter
     */
    private static function getSafeParam($p){
        return addslashes($p);
    }

    /**
     * [INSERT]/[UPDATE]
     * @access public
     * 当为 INSERT 时，参数有 2 个
     * @param array table_name 表名
     * @param string arr_save 字段名运算符号值
     * How To use
        save(
            'pb_user',
            array(
                'username=test',
                'phone=15010988888'
            )
        );
     *
     * 当为 UPDATE 时，参数有 3 个
     * @access public
     * @param array  table_name 表名
     * @param string arr_save 字段名运算符号值
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * How To use
        save(
            'pb_user',
            array(
                'username=test',
                'phone=15010988888'
            ),
            array(
                'userid=' . $param[0],
                'phone='  . $param[1]
            )
        );
     * 
     */
    public function save(){
        // overloadFun可以随便定义，但为了命名规范，建议宝贝为与此函数名一样，
        // 后面的尾随数值为参数个数，以方便管理
        $name = "save".func_num_args(); 
        return call_user_func_array(array($this,$name), func_get_args());
    }

    /**
     * [INSERT]插入一条记录
     * @access private
     * @param array table_name 表名
     * @param string arr_save 字段名运算符号值
     * @return
     * INSERT INTO `pb_user` (`username` ,`phone`) VALUES ('test', '15010988888')
     */
    // private function save2($table_name, $arr_save){
    private function save2(){
        // 动态获取参数
        $arg_list = func_get_args();
        $table_name = self::getSafeParam($arg_list[0]);
        $arr_save = $arg_list[1];
        // 开始处理
        $_sql = "INSERT INTO `{$table_name}` ";
        $_sql .= "(";
        $left = array();  // 键名组
        $right = array(); // 键值组
        foreach($arr_save as $k => $v){
            $v = self::getSafeParam($v);
            $lrf = explode("=", $v);
            $left[$k] = $lrf[0];
            $right[$k] = $lrf[1];
            if($left[$k] == '' || $right[$k] == ''){
                continue;
            }
            if($k == 0){
                $_sql .= "`{$left[$k]}`";
            }else{
                $_sql .= " ,`{$left[$k]}`";
            }
        }
        $_sql .= ") VALUES (";
        foreach($arr_save as $k => $v){
            $v = self::getSafeParam($v);
            if($left[$k] == '' || $right[$k] == ''){
                continue;
            }
            if($k == 0){
                $_sql .= "'{$right[$k]}'";
            }else{
                $_sql .= ", '{$right[$k]}'";
            }
        }
        $_sql .= ")";
        // echo $_sql;
        // echo '<br/>';
        // exit;
        // execute sql
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误 返回结果
        return $this->catchSaveOrRemoveErr();
    }

    /**
     * [UPDATE]更新一条记录
     * @access private
     * @param array table_name 表名
     * @param string arr_save 字段名运算符号值
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * @return
     * Such sql
     * UPDATE `pb_user` SET `username`='test' ,`phone`='15010988888' WHERE `userid`='2' AND `phone`='15010988888'
     */
    // private function save3($table_name, $arr_save, $arr_condition){
    private function save3(){
        // 动态获取参数
        $arg_list = func_get_args();
        $table_name = self::getSafeParam($arg_list[0]);
        $arr_save = $arg_list[1];
        $arr_condition = $arg_list[2];
        // 开始处理
        $_sql = "UPDATE `{$table_name}` SET ";
        $left = array();  // 键名组
        $right = array(); // 键值组
        foreach($arr_save as $k => $v){
            $v = self::getSafeParam($v);
            $lrf = explode("=", $v);
            $left[$k] = $lrf[0];
            $right[$k] = $lrf[1];
            if($left[$k] == '' || $right[$k] == ''){
                continue;
            }
            if($k == 0){
                $_sql .= "`{$left[$k]}`='{$right[$k]}'";
            }else{
                $_sql .= " ,`{$left[$k]}`='{$right[$k]}'";
            }
        }
        // 拼接 where 之后内容
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // echo $_sql;
        // echo '<br/>';
        // exit;
        // execute sql
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误 返回结果
        return $this->catchSaveOrRemoveErr();
    }

    /**
     * [SELECT]通过某一字段或多个字段查找
     * @access public
     * @param array arr_findByWhat 要查询 字段名 列表
     * @param string table_name 表名
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * @return array such as
     * Array ( [status] => nodata [data] => Array ( ) )
     * Array ( [status] => data [data] => Array ( [0] => Array ( [userid] => 1 [phone] => 15010988888 ) ) )
     * How to use
     * findByX($arr_findByWhat, $table_name, $arr_condition)
        findByX(
            array(
                'userid',
                'phone'
            ), 
            'pb_user', 
            array(
                'userid=1',
                'phone=15010988888'
            )
        );
     * 查询出来的结果按照 userid 或者 id 降序排列，当表名为 前缀_user 时，默认使用 userid 降序排列，其他默认用 id 降序排列
     */
    public function findByX($arr_findByWhat, $table_name, $arr_condition){
        $table_name = self::getSafeParam($table_name);
        if(sizeof($arr_findByWhat) < 1 || sizeof($arr_condition) < 1){
            return Tools::returnBeanData('unSupport arr_findByWhat OR arr_condition');
        }
        $_sql = "SELECT ";
        // 获取要查询的 字段名 列表
        foreach($arr_findByWhat as $k => $v){
            $v = self::getSafeParam($v);
            // if($k == 0){
            //     $_sql .= "`{$arr_findByWhat[$k]}`";
            // }else{
            //     $_sql .= " ,`{$arr_findByWhat[$k]}`";
            // }
            if($k == 0){
                $_sql .= "`{$v}`";
            }else{
                $_sql .= " ,`{$v}`";
            }
        }
        $_sql .= " FROM `{$table_name}` ";
        // 查询条件
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // 降序排列
        if(self::isUserTable($table_name)){
            $_sql .= " ORDER BY `userid` DESC";
        }else{
            $_sql .= " ORDER BY `id` DESC";
        }
        // echo $_sql;
        // echo '<br/>';
        // exit;
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误
        if($this->_mysqli->errno){
            return Tools::returnBeanData('语法错误,' . $this->_mysqli->error, array());
        }
        $returnRes = Tools::returnBeanData('nodata', array());
        while($_assoc = $_res->fetch_assoc()){
            $returnRes['status'] = 'data';
            $returnRes['data'][] = $_assoc;
        }
        return $returnRes;
    }

    /**
     * [SELECT]SELECT * 方法 慎用
     * [SELECT]SELECT * 方法 慎用
     * @access public
     * @param string table_name 表名
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * @return array such as
     * Array ( [status] => nodata [data] => Array ( ) )
     * Array ( [status] => data [data] => Array ( [0] => Array ( [userid] => 1 [phone] => 15010988888 ) ) )
     * How to use
     * findByX($table_name, $arr_condition)
        findByX(
            'pb_user', 
            array(
                'userid=1',
                'phone=15010988888'
            )
        );
     * 查询出来的结果按照 userid 或者 id 降序排列，当表名为 前缀_user 时，默认使用 userid 降序排列，其他默认用 id 降序排列
     */
    public function findAll($table_name, $arr_condition){
        $table_name = self::getSafeParam($table_name);
        $_sql = "SELECT *";
        $_sql .= " FROM `{$table_name}` ";
        // 查询条件
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // 降序排列
        if(self::isUserTable($table_name)){
            $_sql .= " ORDER BY `userid` DESC";
        }else{
            $_sql .= " ORDER BY `id` DESC";
        }
        // echo $_sql;
        // echo '<br/>';
        // exit;
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误
        if($this->_mysqli->errno){
            return Tools::returnBeanData('语法错误,' . $this->_mysqli->error, array());
        }
        $returnRes = Tools::returnBeanData('nodata', array());
        while($_assoc = $_res->fetch_assoc()){
            $returnRes['status'] = 'data';
            $returnRes['data'][] = $_assoc;
        }
        return $returnRes;
    }

    /**
     * [SELECT]SELECT * 【分页】方法 慎用
     * [SELECT]SELECT * 【分页】方法 慎用
     * @access public
     * @param string table_name 表名
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * @param int page 页数
     * @param int percount 每页取多少条数据,默认15条
     * @return array such as
     * Array ( [status] => nodata [data] => Array ( ) )
     * Array ( [status] => data [data] => Array ( [0] => Array ( [userid] => 1 [phone] => 15010988888 ) ) )
     * How to use
     * findByX($table_name, $arr_condition, $page, $percount=15)
     * 查询出来的结果按照 userid 或者 id 降序排列，当表名为 前缀_user 时，默认使用 userid 降序排列，其他默认用 id 降序排列
     */
    public function findAllByPage($table_name, $arr_condition, $page, $percount=15){
        $table_name = self::getSafeParam($table_name);
        $_sql = "SELECT *";
        $_sql .= " FROM `{$table_name}` ";
        // 查询条件
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // 降序排列
        if(self::isUserTable($table_name)){
            $_sql .= " ORDER BY `userid` DESC";
        }else{
            $_sql .= " ORDER BY `id` DESC";
        }
        // 拼接LIMIT
        // limit是mysql的语法
        // select * from table limit m,n
        // 其中m是指记录开始的index，从0开始，表示第一条记录
        // n是指从第m+1条开始，取n条。
        // select * from tablename limit 2,4
        // 即取出第3条至第6条，4条记录
        // p0 0,15
        // p1 15,15
        // $percount 合法化
        $percount = (int)$percount;
        if($percount < 0 ){
            $percount = 15; // 恢复默认
        }
        $start = $page * $percount;
        $_sql .= " LIMIT {$start},{$percount}";
        // echo $_sql;
        // echo '<br/>';
        // exit;
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误
        if($this->_mysqli->errno){
            return Tools::returnBeanData('语法错误,' . $this->_mysqli->error, array());
        }
        $returnRes = Tools::returnBeanData('nodata', array());
        while($_assoc = $_res->fetch_assoc()){
            $returnRes['status'] = 'data';
            $returnRes['data'][] = $_assoc;
        }
        return $returnRes;
    }

    /**
     * [SELECT]通过某一字段或多个字段查找 返回查询到的结果的数量
     * @access public
     * @param array arr_findByWhat 要查询 字段名 列表
     * @param string table_name 表名
     * @param array arr_condition 查询条件 字段名运算符号值 列表
     * @return array such as
     * Array ( [status] => nodata [data] => count )
     * Array ( [status] => data [data] => count )
     */
    public function findByXGetCount($arr_findByWhat, $table_name, $arr_condition){
        $table_name = self::getSafeParam($table_name);
        if(sizeof($arr_findByWhat) < 1 || sizeof($arr_condition) < 1){
            return Tools::returnBeanData('unSupport arr_findByWhat OR arr_condition');
        }
        $_sql = "SELECT ";
        // 获取要查询的 字段名 列表
        foreach($arr_findByWhat as $k => $v){
            $v = self::getSafeParam($v);
            // if($k == 0){
            //     $_sql .= "`{$arr_findByWhat[$k]}`";
            // }else{
            //     $_sql .= " ,`{$arr_findByWhat[$k]}`";
            // }
            if($k == 0){
                $_sql .= "`{$v}`";
            }else{
                $_sql .= " ,`{$v}`";
            }
        }
        $_sql .= " FROM `{$table_name}` ";
        // 查询条件
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // 降序排列
        if(self::isUserTable($table_name)){
            $_sql .= " ORDER BY `userid` DESC";
        }else{
            $_sql .= " ORDER BY `id` DESC";
        }
        // echo $_sql;
        // echo '<br/>';
        // exit;
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误
        if($this->_mysqli->errno){
            return Tools::returnBeanData('语法错误,' . $this->_mysqli->error, array());
        }
        $count = 0;
        while($_assoc = $_res->fetch_assoc()){
            $count++;
        }
        $returnRes = Tools::returnBeanData('data', $count);
        return $returnRes;
    }

    /**
     * [DELETE] 通过条件 删除
     * 作者建议：谨慎使用删除方法，一般采用 update数据记录状态 代替 delete 方法
     * @access public
     * @param string table_name
     * @param array arr_condition
     * @return
     * How to use
     * remove($table_name, $arr_condition)
        remove(
            'pb_user',
            array(
                'username=test',
                'phone=15010988888'
            )
        );
     */
    public function remove($table_name, $arr_condition){
        $table_name = self::getSafeParam($table_name);
        $_sql = "DELETE FROM `{$table_name}` ";
        // 查询条件
        $where = self::translateWhere($arr_condition);
        if($where == 'unSupport'){
            return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
        }else{
            $_sql .= $where;
        }
        // return $_sql;
        // execute sql
        $_res = $this->_mysqli->query($_sql);
        // 捕捉错误 返回结果
        return $this->catchSaveOrRemoveErr();
    }

    // 已弃用
    // /**
    //  * 更新或插入数据
    //  * @access public
    //  * 
    //  */
    // public function save($table_name, $arr_condition){
    //     // 分两种情况
    //     // 1 已经存在的数据 对其进行更新 update
    //     // 2 不存在的数据 对其进行插入 insert

    //     // 如何辨识上述两种情况
    //     // 传进来的如果有 id 或者 userid 视为 情况 1
    //     // 非情况1 视为 情况2

    //     $isupdate = false; // 默认非情况 1
    //     $isuserid = false; // 默认不存在 userid
    //     $isid = false;     // 默认不存在 id

    //     $left = array();  // 键名组
    //     $right = array(); // 键值组

    //     // userid 和 id 目前是互斥的，可以同时不存在，或者其一存在。但两者不能同时存在
    //     foreach($arr_condition as $k => $v){
    //         $lrf = explode('=', $v);
    //         $left[$k] = $lrf[0]; // 键名
    //         $right[$k] = $lrf[1]; // 键值
    //         if($left[$k] == 'userid'){
    //             $isuserid = true;
    //             $isupdate = true;
    //         }
    //         if($left[$k] == 'id'){
    //             $isid = true;
    //             $isupdate = true;
    //         }
    //     }

    //     // userid 和 id 目前是互斥的
    //     if($isuserid && $isid){
    //         return Tools::returnBeanData('must be userid or id, can not be userid and id');
    //     }

    //     $_sql = "";
    //     if($isupdate){
    //         // 更新
    //         $_sql = "UPDATE `{$table_name}` SET ";
    //         $where = "";
    //         if($isuserid){
    //             // 通过 userid 更新
    //             $where = "WHERE ";
    //         }else{
    //             // 通过 id 更新

    //         }
    //     }else{
    //         // 插入

    //     }
    // }

    /**
     * 捕捉在 save / remove 过程中 产生的错误
     * @access private
     * @return
     * fail string _mysqli->error
     * success int(string) 0
     */
    private function catchSaveOrRemoveErr(){
        // 捕捉错误
        if($this->_mysqli->errno){
            return Tools::returnBeanData($this->_mysqli->error);
        }else{
            // 成功
            return Tools::returnBeanData('success');
        }
    }

    /**
     * 解析生成 where 之后的条件
     * 仅能将条件用 AND 连接，如果有 OR ，请自行转成 AND 逻辑 再调用相关方法
     * @access private
     * @param array arr_condition
     * @return string sql
     * " WHERE `id`='1' AND `age`='18'"
     */
    private static function translateWhere($arr_condition){
        $_sql = ' WHERE ';
        foreach($arr_condition as $k => $v){
            $v = self::getSafeParam($v);
            // 解析 $v 
            // 可能时 a=b / a>b / a<b / a<>b
            $left = '';   // 键名
            $right = '';  // 键值
            $fuhao = '';  // 符号 = > < <> >= <=
            // 坚决不能更改判断顺序!坚决不能更改判断顺序!
            if(strpos($v, "<>")){
                $fuhao = '<>';
            }elseif(strpos($v, ">=")){
                $fuhao = '>=';
            }elseif(strpos($v, "<=")){
                $fuhao = '<=';
            }elseif(strpos($v, "=")){
                $fuhao = '=';
            }elseif(strpos($v, ">")){
                $fuhao = '>';
            }elseif(strpos($v, "<")){
                $fuhao = '<';
            }else{
                // return Tools::returnBeanData('unSupport arr_condition, must be a=b / a>b / a<b / a<>b');
                return 'unSupport';
            }
            $lrf = explode($fuhao, $v);
            $left = $lrf[0];
            $right = $lrf[1];
            if($left == '' || $right == '' || $fuhao == ''){
                continue;
            }else{
                if($k == 0){
                    $_sql .= "`{$left}`{$fuhao}'{$right}'";
                }else{
                    $_sql .= " AND `{$left}`{$fuhao}'{$right}'";
                }
            }
        }
        return $_sql;
    }

    /**
     * 查是否为user功能表
     * 因为user功能表的主键的userid，而非user功能表的主键是id
     * 区别user表，主要是看是否符合 前缀_user 名称结构
     * @access private
     * @param string table_name
     * @return boolean ture-user表 false-非user表
     */
    private static function isUserTable($table_name){
        $arr = explode("_", $table_name);
        if($arr[1] == 'user' && !isset($arr[2])){
            return true;
        }else{
            return false;
        }
    }
}
